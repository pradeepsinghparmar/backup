<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Attendance;
use App\Models\Attendanceday;
use App\Models\Holiday;
use App\Models\Month;
use App\Models\Leave;
use Hash;
use Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
class AttendanceController extends Controller
{
    public function index(Request $request){
        $id = Auth::user()->id;
        if ($request->emp_id != null && $request->month != null && $request->year != null) {
             $empid = $request->emp_id;
             $m_day = $request->month;
             $y_day = $request->year;
            $users = User::whereIsAdmin('0')->get();
            $months = Month::where('month',$m_day)->orderBy('day','ASC')->get();
            $holiday = Holiday::where('month',$m_day)->where('year',$y_day)->orderBy('day','ASC')->get();
            foreach($holiday as $row1){
        	   $returnArray1[] = $row1;
            }
            if(!empty($returnArray1)){
                $holi_names = array_column($returnArray1, 'day');
                $json_holi_result = json_encode($holi_names);
            }else{
                $holi_names ='';
                $json_holi_result = '';
            }
            $month_day_count = $months->count();
            //   $emplist = Attendance::distinct()->get(['employee_id']);
            $emplist = Attendance::where('employee_id',$empid)->distinct()->get(['employee_id']);
        }elseif ($request->emp_id == '' && $request->month != null && $request->year != null) {
            $empid = $request->emp_id;
            $m_day = $request->month;
            $y_day = $request->year;
            $users = User::whereIsAdmin('0')->get();
            $months = Month::where('month',$m_day)->orderBy('day','ASC')->get();
            $holiday = Holiday::where('month',$m_day)->where('year',$y_day)->orderBy('day','ASC')->get();
            foreach($holiday as $row1){
        	   $returnArray1[] = $row1;
            }
            if(!empty($returnArray1)){
                $holi_names = array_column($returnArray1, 'day');
                $json_holi_result = json_encode($holi_names);
            }else{
                $holi_names ='';
                $json_holi_result = '';
            }
            $month_day_count = $months->count();
            $emplist = Attendance::distinct()->get(['employee_id']);
        }else{
            $m_day = date('m');
            $y_day = date('Y');
            $empid = '';

            $users = User::whereIsAdmin('0')->get();
            $months = Month::where('month',date('m'))->orderBy('day','ASC')->get();
            $holiday = Holiday::where('month',date('m'))->where('year',date('Y'))->orderBy('day','ASC')->get(); 
            foreach($holiday as $row1){
                $returnArray1[] = $row1;
            }
            if(!empty($returnArray1)){
                $holi_names = array_column($returnArray1, 'day');
                $json_holi_result = json_encode($holi_names);
            }else{
                $holi_names ='';
                $json_holi_result = '';
            }
            $month_day_count = $months->count();
            $emplist = Attendance::distinct()->get(['employee_id']);
        }
        return view('admin.attendance/index', compact('users','emplist','months','month_day_count','holiday','json_holi_result','m_day','y_day','empid'));
    } 

    public function employee_att(Request $request){
       
        if ($request->month != null && $request->year != null) {
            $m_day = $request->month;
            $y_day = $request->year;
            $users = User::whereIsAdmin('0')->get();
            $months = Month::where('month',$m_day)->orderBy('day','ASC')->get();
            $month_day_count = $months->count();
            $holiday = Holiday::where('month',$m_day)->where('year',$y_day)->orderBy('day','ASC')->get(); 
            $userlist = Attendance::select('day')->where('employee_id', Auth::user()->id)->where('year', $y_day)->where('month', $m_day)->get();
            $month_day_attendance = $userlist->count();
            foreach($userlist as $row){
                $returnArray[] = $row;
            }
            if(!empty($returnArray)){
                $last_names = array_column($returnArray, 'day');
                $json_result = json_encode($last_names);
            }else{
                $last_names ='';
                $json_result = '';
            }
        }else{
            $m_day = date('m');
            $y_day = date('Y');
            $users = User::whereIsAdmin('0')->get();
            $months = Month::where('month',$m_day)->orderBy('day','ASC')->get();
            $month_day_count = $months->count();
            $holiday = Holiday::where('month',$m_day)->where('year',$y_day)->orderBy('day','ASC')->get();
            $userlist = Attendance::select('day')->where('employee_id', Auth::user()->id)->where('year', $y_day)->where('month', $m_day)->get();
            $month_day_attendance = $userlist->count();
            foreach($userlist as $row){
                $returnArray[] = $row;
            }
            if(!empty($returnArray)){
                $last_names = array_column($returnArray, 'day');
                $json_result = json_encode($last_names);
            }else{
                $last_names ='';
                $json_result = '';
            }
        }
        return view('admin.attendance/employee_att', compact('users','months','json_result','month_day_count','month_day_attendance','userlist','holiday','m_day','y_day'));
    }

    public function employee_hour_att(Request $request){

        if ($request->month != null && $request->year != null) {
            $m_day = $request->month;
            $y_day = $request->year;
            $users = User::whereIsAdmin('0')->get();
            $months = Month::where('month',$m_day)->orderBy('day','ASC')->get();
            $month_day_count = $months->count();
            $holiday = Holiday::where('month',$m_day)->where('year',$y_day)->orderBy('day','ASC')->get();
            $userlist = Attendance::select('day')->where('employee_id', Auth::user()->id)->where('year', $y_day)->where('month', $m_day)->get();
            $month_day_attendance = $userlist->count();
            foreach($userlist as $row){
                $returnArray[] = $row;
            }
            if(!empty($returnArray)){
                $last_names = array_column($returnArray, 'day');
                $json_result = json_encode($last_names);
            }else{
                $last_names ='';
                $json_result = '';
            }
        }else{
            $m_day = date('m');
            $y_day = date('Y');
            $users = User::whereIsAdmin('0')->get();
            $months = Month::where('month',$m_day)->orderBy('day','ASC')->get();
            $month_day_count = $months->count();
            $holiday = Holiday::where('month',$m_day)->where('year',$y_day)->orderBy('day','ASC')->get();
            $userlist = Attendance::select('day')->where('employee_id', Auth::user()->id)->where('year', $y_day)->where('month', $m_day)->get();
            $month_day_attendance = $userlist->count();
            foreach($userlist as $row){
                $returnArray[] = $row;
            }
            if(!empty($returnArray)){
                $last_names = array_column($returnArray, 'day');
                $json_result = json_encode($last_names);
            }else{
                $last_names ='';
                $json_result = '';
            }
        }
        return view('admin.attendance/employee_hour_att', compact('users','months','json_result','month_day_count','month_day_attendance','userlist','holiday','m_day','y_day'));
    }

    public function employee_att_details(Request $request,$id){
        $employee_id = $id;
        $emp_att = Attendance::where('employee_id',$id)->where('month',date('m'))->where('year',date('Y'))->orderBy('date','DESC')->get();
        // dd($emp_att);
        $present_att = Attendance::where('employee_id',$id)->where('month',date('m'))->where('year',date('Y'))->count();
        $late_att = Attendance::where('employee_id',$id)->where('month',date('m'))->where('year',date('Y'))->where('late','Yes')->count();
        $holiday_att = Holiday::where('month',date('m'))->where('year',date('Y'))->count();
        // dd(date('t'));
        $users = User::whereIsAdmin('0')->get();
        return view('admin.attendance/employee_att_details',compact('emp_att','present_att','late_att','holiday_att','employee_id','users'));
    }

    // public function all_employee_hour_attendance(){
       
    //       $users = User::whereIsAdmin('0')->get();
    //       $months = Month::where('month',date('m'))->orderBy('day','ASC')->get(); 
    //       $holiday = Holiday::where('month',date('m'))->where('year',date('Y'))->orderBy('day','ASC')->get(); 
    //       $month_day_count = $months->count();
    //       $emplist = Attendance::distinct()->get(['employee_id']);
        
    //      return view('admin.attendance/all_employee_hour_attendance', compact('users','emplist','months','month_day_count','holiday'));
        
    // }

    public function all_employee_hour_attendance(Request $request){

        if ($request->emp_id != null && $request->month != null && $request->year != null) {
            $empid = $request->emp_id;
            $m_day = $request->month;
            $y_day = $request->year;
            $users = User::whereIsAdmin('0')->get();
            $months = Month::where('month',$m_day)->orderBy('day','ASC')->get(); 
            $holiday = Holiday::where('month',$m_day)->where('year',$y_day)->orderBy('day','ASC')->get();
            $month_day_count = $months->count();
            $emplist = Attendance::where('employee_id',$empid)->distinct()->get(['employee_id']);
        }else if ($request->emp_id == '' && $request->month != null && $request->year != null) {
            $empid = $request->emp_id;
            $m_day = $request->month;
            $y_day = $request->year;
            $users = User::whereIsAdmin('0')->get();
            $months = Month::where('month',$m_day)->orderBy('day','ASC')->get(); 
            $holiday = Holiday::where('month',$m_day)->where('year',$y_day)->orderBy('day','ASC')->get();
            $month_day_count = $months->count();
            $emplist = Attendance::distinct()->get(['employee_id']);
        }else{
            $m_day = date('m');
            $y_day = date('Y');
            $empid = '';
            $users = User::whereIsAdmin('0')->get();
            $months = Month::where('month',date('m'))->orderBy('day','ASC')->get(); 
            $holiday = Holiday::where('month',date('m'))->where('year',date('Y'))->orderBy('day','ASC')->get();
            $month_day_count = $months->count();
            $emplist = Attendance::distinct()->get(['employee_id']);
        }
        return view('admin.attendance/all_employee_hour_attendance', compact('users','emplist','months','month_day_count','holiday','m_day','y_day','empid'));
    }

    public function employee_hour_attendance(Request $request,$id){
        if ($request->month != null && $request->year != null) {
            $m_day = $request->month;
            $y_day = $request->year;
            $users = User::whereIsAdmin('0')->get();
            $months = Month::where('month',$m_day)->orderBy('day','ASC')->get(); 
            $month_day_count = $months->count();
            $userlist = Attendance::select('day')->where('employee_id', $id)->where('year', $y_day)->where('month', $m_day)->get();
            $month_day_attendance = $userlist->count();
            foreach($userlist as $row){
                $returnArray[] = $row;
            }
            if(!empty($returnArray)){
                $last_names = array_column($returnArray, 'day');
                $json_result = json_encode($last_names);
            }else{
                $last_names ='';
                $json_result = '';
            }
        }else{
            $m_day = date('m');
            $y_day = date('Y');
            $users = User::whereIsAdmin('0')->get();
            $months = Month::where('month',$m_day)->orderBy('day','ASC')->get();
            $month_day_count = $months->count();
            $userlist = Attendance::select('day')->where('employee_id', $id)->where('year', $y_day)->where('month', $m_day)->get();
            $month_day_attendance = $userlist->count();
            foreach($userlist as $row){
                $returnArray[] = $row;
            }
            if(!empty($returnArray)){
                $last_names = array_column($returnArray, 'day');
                $json_result = json_encode($last_names);
            }else{
                $last_names ='';
                $json_result = '';
            }
        }
        return view('admin.attendance/employee_hour_attendance', compact('users','months','json_result','month_day_count','month_day_attendance','userlist','m_day','y_day'));
    }

    public function employee_calendar_attendance(Request $request,$id){
        if ($request->month != null && $request->year != null) {
            $m_day = $request->month;
            $y_day = $request->year;
            $users = User::whereIsAdmin('0')->get();
            $months = Month::where('month',$m_day)->orderBy('day','ASC')->get();
            $month_day_count = $months->count();
            $userlist = Attendance::select('day')->where('employee_id', $id)->where('year', $y_day)->where('month', $m_day)->get();
            $month_day_attendance = $userlist->count();
            foreach($userlist as $row){
                $returnArray[] = $row;
            }
            if(!empty($returnArray)){
                $last_names = array_column($returnArray, 'day');
                $json_result = json_encode($last_names);
            }else{
                $last_names ='';
                $json_result = '';
            }
        }else{
            $m_day = date('m');
            $y_day = date('Y');
            $users = User::whereIsAdmin('0')->get();
            $months = Month::where('month',$m_day)->orderBy('day','ASC')->get();
            $month_day_count = $months->count();
            $userlist = Attendance::select('day')->where('employee_id', $id)->where('year', $y_day)->where('month', $m_day)->get();
            $month_day_attendance = $userlist->count();
            foreach($userlist as $row){
                $returnArray[] = $row;
            }
            if(!empty($returnArray)){
                $last_names = array_column($returnArray, 'day');
                $json_result = json_encode($last_names);
            }else{
                $last_names ='';
                $json_result = '';
            }
        }
        return view('admin.attendance/employee_calendar_attendance', compact('users','months','json_result','month_day_count','month_day_attendance','userlist','m_day','y_day'));
    }

    //public function create_attendance(){

        //return view('admin.attendance/create');
    // }

    public function employee_attendance(Request $request,$id){
        $employee_id = $id;
        $emp_att = Attendance::where('employee_id',$id)->where('month',date('m'))->where('year',date('Y'))->orderBy('date','DESC')->get(); 
        // dd($emp_att);
        $present_att = Attendance::where('employee_id',$id)->where('month',date('m'))->where('year',date('Y'))->count();
        $late_att = Attendance::where('employee_id',$id)->where('month',date('m'))->where('year',date('Y'))->where('late','Yes')->count();
        $holiday_att = Holiday::where('month',date('m'))->where('year',date('Y'))->where('created_at','<=',date("Y-m-d"))->count();
        $users = User::whereIsAdmin('0')->get();
        return view('admin.attendance/employee_attendance',compact('emp_att','present_att','late_att','holiday_att','employee_id','users'));
    }

    public function search_attendance(Request $request){
        $smonth = $request->month;
        $syear = $request->year;
        if(!empty($smonth) && !empty($syear)){
            $users = User::whereIsAdmin('0')->get();
            $months = Month::where('month',$smonth)->orderBy('day','ASC')->get();
            $month_day_count = $months->count();
            $userlist = Attendance::select('day')->where('employee_id', Auth::user()->id)->where('year', $syear)->where('month', $smonth)->get();
            $month_day_attendance = $userlist->count();
            foreach($userlist as $row){
                $returnArray[] = $row;
            }
            if(!empty($returnArray)){
                $last_names = array_column($returnArray, 'day');
                $json_result = json_encode($last_names);
            }else{
                $last_names ='';
                $json_result = '';
            }
            return view('admin.attendance/index', compact('users','months','json_result','month_day_count','month_day_attendance','smonth','syear')); 
        }elseif(!empty($smonth) && !empty($syear)){
            $users = User::whereIsAdmin('0')->get();
            $months = Month::where('month',$smonth)->orderBy('day','ASC')->get();
            $month_day_count = $months->count();
            $userlist = Attendance::select('day')->where('employee_id', Auth::user()->id)->where('year', $syear)->where('month', $smonth)->get();
            $month_day_attendance = $userlist->count();
            foreach($userlist as $row){
                $returnArray[] = $row;
            }
            if(!empty($returnArray)){
                $last_names = array_column($returnArray, 'day');
                $json_result = json_encode($last_names);
            }else{
                $last_names ='';
                $json_result = ''; 
            }
            return view('admin.attendance/index', compact('users','months','json_result','month_day_count','month_day_attendance','smonth','syear')); 
        }
    }

    public function holiday_list(){
        $holiday_list = Holiday::orderBy('ID','DESC')->get(); 
        return view('admin.attendance.holiday_list',compact('holiday_list'));
    }
    
    public function create_holiday(){
        return view('admin.attendance.create_holiday');
    } 

    public function store_holiday(Request $request){
        $data = array();
        for ($x = 0; $x < count($request->date); $x ++) {
            $data['date']= $request->date[$x];
            $data['day']= date('d',strtotime($request->date[$x]));
            $data['month']= date('m',strtotime($request->date[$x]));
            $data['year']= date('Y',strtotime($request->date[$x]));
            $data['occasion']= $request->occasion[$x];
            Holiday::create($data);
        }
        return redirect()->route('holiday_list')->with('success','Holiday Has Been Added successfully');
    }

    public function edit_holiday(Request $request,$id)
    {
        $holiday_edit = Holiday::where('id',$id)->first(); 
        return view('admin.attendance.edit_holiday',compact('holiday_edit'));
    }

    public function update_holiday(Request $request,$id){
        $data = array();
        $data['date']= $request->date;
        $data['day']= date('d',strtotime($request->date));
        $data['month']= date('m',strtotime($request->date));
        $data['year']= date('Y',strtotime($request->date));
        $data['occasion']= $request->occasion;
        Holiday::where('id',$id)->update($data);
        return redirect()->route('holiday_list')->with('success','Holiday Has Been Updated successfully');
    }

    public function delete_holiday($id){
        $category = Holiday::where('id',$id)->delete();
        return redirect()->route('holiday_list');
    }

    public function leave_list(){
        $leave_list = Leave::where('user_id',Auth::user()->id)->orderBy('ID','DESC')->get(); 
        return view('admin.attendance.leave_list',compact('leave_list'));
    }

    public function create_leave(){
        return view('admin.attendance.create_leave');
    } 

    public function store_leave(Request $request){
        $data = array();
        for ($x = 0; $x < count($request->date); $x ++) {
            $data['user_id']=Auth::user()->id;
            $data['date']= $request->date[$x];
            $data['day']= date('d',strtotime($request->date[$x]));
            $data['month']= date('m',strtotime($request->date[$x]));
            $data['year']= date('Y',strtotime($request->date[$x]));
            $data['occasion']= $request->occasion[$x];
            Leave::create($data);
        }
        return redirect()->route('leave_list')->with('success','Holiday Has Been Added successfully');
    }

    public function edit_leave(Request $request,$id)
    {
        $leave_edit = Leave::where('id',$id)->first(); 
        return view('admin.attendance.leave_edit',compact('leave_edit'));
    }

    public function update_leave(Request $request,$id){
        $data = array();
        $data['user_id']=Auth::user()->id;
        $data['date']= $request->date;
        $data['day']= date('d',strtotime($request->date));
        $data['month']= date('m',strtotime($request->date));
        $data['year']= date('Y',strtotime($request->date));
        $data['occasion']= $request->occasion;
        Leave::where('id',$id)->update($data);
        return redirect()->route('leave_list')->with('success','Holiday Has Been Updated successfully');
    }

    public function delete_leave($id){
        $category = Leave::where('id',$id)->delete();
        return redirect()->route('leave_list');
    }

}