<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\User;
//use App\Models\Employee;
use App\Models\Role;
use App\Models\Vendor;
use App\Models\Customer;
use App\Models\Project;
use App\Models\Task;
use App\Models\Permission;
use App\Models\Userpermission;
use App\Models\Attendance;
use App\Models\Allapi;
//use App\Models\AccessSites;
use App\Models\RegisteredUser;
use App\Mail\VerifyMail;
use Hash;
use Mail;
class UserController extends Controller
{
    public function index(){
        $users = User::whereIsAdmin('0')->get();
        return view('admin.user_list', compact('users'));
    }

    public function delete_user($id){
        $user = User::find($id);
        $user->delete();
        return redirect()->route('user.index');
    }

    public function create_employee(Request $request){
         $role = Role::where('role_status', '1')->orderBy('role_id', 'DESC')->get();
        return view('admin.employee.create',compact('role'));
    }

    public function employee_list(Request $request){
        $staff = User::orderBy('id', 'DESC')->get();
        $role = Role::where('role_status', '1')->orderBy('role_id', 'DESC')->get();
        return view('admin.employee.index', compact('staff','role'));
    }

    public function store_employee(Request $request){
        $ph = $request->country_code.$request->phone;
        $message = '';
        $error = 0;
        if (User::where('email', $request->email)->exists()) {
            $message .= 'Email id already registrated. ';
            $error = 1;
        }
        if(User::Where('phone', $ph)->exists()){
            $message .= 'Phone No. already registrated.';
            $error = 1;
        }
        if($error == 1){
            return redirect()->route('create_employee')->with('error',$message);
        }else{
            $data = array();
            $data['name']= $request->name;
            $data['last_name']= $request->last_name;
            $data['email']= $request->email;
            $data['phone']= $ph;
            $data['employee_type']= $request->employee_type;
            $data['password']= Hash::make($request->password);
            $data['hourly_rate']= $request->hourly_rate;
            $data['salary']= $request->salary;
            $data['role']= $request->role;
            $data['login_status']= '1';

            $getd = User::create($data);
            $editRole = Role::where('role_id',3)->first();
            return redirect()->route('employee_list')->with('success','Employee Has Been Added successfully');
        }
    }

    public function edit_employee($id){
        $editstaff = User::where('id',$id)->first();
        $role = Role::where('role_status', '1')->orderBy('role_id', 'DESC')->get();
        return view('admin.employee.edit', compact('editstaff','role'));
    }

    public function update_employee(Request $request,$id){
        $data = array();
        $data['name']= $request->name;
        $data['last_name']= $request->last_name;
        //$data['email']= $request->email;
        $data['phone']= $request->phone;
        $data['employee_type']= $request->employee_type;
        if($request->password !=''){
            $data['password']= Hash::make($request->password);
        }
        $data['hourly_rate']= $request->hourly_rate;
        $data['salary']= $request->salary;
        $data['role']= $request->role;
        User::where('id',$id)->update($data);
        return redirect()->route('employee_list')->with('success','Staff Has Been Updated successfully');
    }

    public function delete_employee($id){
        $category = User::where('id',$id)->delete();   
        //$attendance = Attendance::where('employee_id',$id)->delete();
        return redirect()->route('employee_list');
    }

    public function change_employee_status(Request $request){
        $staff_id = $request->staff_id;
        $details = User::where('id',$staff_id)->first();
        $status = $details->login_status;
        if($status == '0'){
            $newStatus = '1';
        }else if($status == '1'){
            $newStatus = '0';
        }
        $update['login_status'] = $newStatus;
        User::where('id',$staff_id)->update($update);
        echo $status;
    }

    public function create_vendor(Request $request){
        return view('admin.vendor.create');
    }

    public function vendor_list(Request $request){
        $staff = Vendor::orderBy('id', 'DESC')->get();
        return view('admin.vendor.index', compact('staff'));
    }

    public function store_vendor(Request $request){

        $ph = $request->country_code.$request->phone;
        $message = '';
        $error = 0;
        if (Vendor::where('email', $request->email)->exists()) {
            $message .= 'Email id already registred. ';
            $error = 1;
        }
        if(Vendor::Where('phone', $ph)->exists()){
            $message .= 'Phone No. already registrated.';
            $error = 1;
        }
        if($error == 1){
            return redirect()->route('create_vendor')->with('error',$message);
        }else{
            $data = array();
            $data['name']= $request->name;
            $data['email']= $request->email;
            $data['phone']= $ph;
            $data['address']= $request->address;
            //$data['status']= $request->status;
            $getd = Vendor::create($data);

            $vendor_id = 'VEN-'.$getd->id;
            Vendor::where('id',$getd->id)->update(['vendor_id'=>$vendor_id]);
            return redirect()->route('vendor_list')->with('success','Vendor Has Been Added successfully');
        }
    }

    public function edit_vendor($id){
        $editstaff = Vendor::where('id',$id)->first();
        return view('admin.vendor.edit', compact('editstaff'));
    }

    public function update_vendor(Request $request,$id){ 
        $data = array();
        $data['name']= $request->name;
        //$data['email']= $request->email;
        $data['phone']= $request->phone;
        $data['address']= $request->address;
        Vendor::where('id',$id)->update($data);
        return redirect()->route('vendor_list')->with('success','Vendor Has Been Updated successfully');
    }

    public function delete_vendor($id){
        $category = Vendor::where('id',$id)->delete();   
        //$attendance = Attendance::where('employee_id',$id)->delete();
        return redirect()->route('vendor_list');
    }

    public function change_vendor_status(Request $request){
        $staff_id = $request->staff_id;
        $details = Vendor::where('id',$staff_id)->first();
        $status = $details->status;
        if($status == '0'){
            $newStatus = '1';
        }else if($status == '1'){
            $newStatus = '0';
        }
        $update['status'] = $newStatus;
        Vendor::where('id',$staff_id)->update($update);
        echo $status;
    }

    public function create_customer(Request $request){
        return view('admin.customer.create');
    }

    public function customer_list(Request $request){
        $staff = Customer::orderBy('id', 'DESC')->get();
        return view('admin.customer.index', compact('staff'));
    }

    public function store_customer(Request $request){
        $ph = $request->country_code.$request->phone;
        $message = '';
        $error = 0;
        if (Customer::where('email', $request->email)->exists()) {
            $message .= 'Email id already registrated. ';
            $error = 1;
        }
        if(Customer::Where('phone', $ph)->exists()){
            $message .= 'Phone No. already registrated.';
            $error = 1;
        }
        if($error == 1){
            return redirect()->route('create_customer')->with('error',$message);
        }else{
            $data = array();
            $data['name']= $request->name;
            $data['email']= $request->email;
            $data['phone']= $ph;
            $data['address']= $request->address;
            //$data['status']= $request->status;
            $getd = Customer::create($data);

            $customer_id = 'CUS-'.$getd->id;
            Customer::where('id',$getd->id)->update(['customer_id'=>$customer_id]);
            return redirect()->route('customer_list')->with('success','Customer Has Been Added successfully');
        }
    }

    public function edit_customer($id){
        $editstaff = Customer::where('id',$id)->first();
        return view('admin.customer.edit', compact('editstaff'));
    }

    public function update_customer(Request $request,$id){ 
        $data = array();
        $data['name']= $request->name;
        $data['phone']= $request->phone;
        $data['address']= $request->address;
        Customer::where('id',$id)->update($data);
        return redirect()->route('customer_list')->with('success','Customer Has Been Updated successfully');
    }

    public function delete_customer($id){
        $category = Customer::where('id',$id)->delete();
        return redirect()->route('customer_list');
    }

    public function change_customer_status(Request $request){
        $staff_id = $request->staff_id;
        $details = Customer::where('id',$staff_id)->first();
        $status = $details->status;
        if($status == '0'){
            $newStatus = '1';
        }else if($status == '1'){
            $newStatus = '0';
        }
        $update['status'] = $newStatus;
        Customer::where('id',$staff_id)->update($update);
        echo $status;
    }

    //project start
    public function create_project(Request $request){
        $vendor = Vendor::where('status', '1')->orderBy('id', 'DESC')->get();
        $customer = Customer::where('status', '1')->orderBy('id', 'DESC')->get();
        return view('admin.project.create', compact('vendor','customer'));
    }

    public function project_list(Request $request){
        $staff = Project::orderBy('id', 'DESC')->get();
        $vendor = Vendor::where('status', '1')->orderBy('id', 'DESC')->get();
        $customer = Customer::where('status', '1')->orderBy('id', 'DESC')->get();
        return view('admin.project.index', compact('staff','vendor','customer'));
    }

    public function store_project(Request $request){
        if (Project::where('name', $request->name)->exists()) {
          return redirect()->route('create_project')->with('error','Project Name already registrated, please check.');
        }else{
            $data = array();
            $data['name']= $request->name;
            $data['description']= $request->description;
            $data['vendor_id']= $request->vendor_id;
            $data['customer_id']= $request->customer_id;
            //$data['status']= $request->status;
            $getd = Project::create($data);

            $project_id = 'PRO-'.$getd->id;
            Project::where('id',$getd->id)->update(['project_id'=>$project_id]);
            return redirect()->route('project_list')->with('success','Project Has Been Added successfully');
        }
    }

    public function edit_project($id){
        $editstaff = Project::where('id',$id)->first();
        $vendor = Vendor::where('status', '1')->orderBy('id', 'DESC')->get();
        $customer = Customer::where('status', '1')->orderBy('id', 'DESC')->get();
        return view('admin.project.edit', compact('editstaff','vendor','customer'));
    }

    public function update_project(Request $request,$id){ 
        $data = array();
        $data['name']= $request->name;
        $data['description']= $request->description;
        $data['vendor_id']= $request->vendor_id;
        $data['customer_id']= $request->customer_id;
        //$data['status']= $request->status;
        Project::where('id',$id)->update($data);
        return redirect()->route('project_list')->with('success','Project Has Been Updated successfully');
    }

    public function delete_project($id){
        Project::where('id',$id)->delete();   
        return redirect()->route('project_list');
    }

    public function change_project_status(Request $request){
        $id = $request->staff_id;
        $details = Project::where('id',$id)->first();
        $status = $details->status;
        if($status == '0'){
            $newStatus = '1';
        }else if($status == '1'){
            $newStatus = '0';
        }
        $update['status'] = $newStatus;
        Project::where('id',$id)->update($update);
        echo $status;
    }
    //project end

    //task start
    public function create_task(Request $request){
        $project = Project::where('status', '1')->orderBy('id', 'DESC')->get();
        $employee = User::where('login_status', '1')->Where('role', 3)->orderBy('id', 'DESC')->get();
        return view('admin.task.create', compact('project','employee'));
    }

    public function task_list(Request $request){
        $staff = Task::orderBy('id', 'DESC')->get();
        $project = Project::where('status', '1')->orderBy('id', 'DESC')->get();
        $employee = User::where('login_status', '1')->Where('role', 3)->orderBy('id', 'DESC')->get();
        return view('admin.task.index', compact('staff','project','employee'));
    }

    public function store_task(Request $request){
        $data = array();
        $data['name']= $request->name;
        $data['description']= $request->description;
        $data['project_id']= $request->project_id;
        $data['employee_id']= $request->employee_id;
        //$data['status']= $request->status;
        $getd = Task::create($data);

        $task_id = 'TSK-'.$getd->id;
        Task::where('id',$getd->id)->update(['task_id'=>$task_id]);
        return redirect()->route('task_list')->with('success','Task Has Been Added successfully');
    }

    public function edit_task($id){
        $editstaff = Task::where('id',$id)->first();
        $project = Project::where('status', '1')->orderBy('id', 'DESC')->get();
        $employee = User::where('login_status', '1')->Where('role', 3)->orderBy('id', 'DESC')->get();
        return view('admin.task.edit', compact('editstaff','project','employee'));
    }

    public function update_task(Request $request,$id){ 
        $data = array();
        $data['name']= $request->name;
        $data['description']= $request->description;
        $data['project_id']= $request->project_id;
        $data['employee_id']= $request->employee_id;
        Task::where('id',$id)->update($data);
        return redirect()->route('task_list')->with('success','Task Has Been Updated successfully');
    }

    public function delete_task($id){
        Task::where('id',$id)->delete();   
        return redirect()->route('task_list');
    }

    public function change_task_status(Request $request){
        $id = $request->staff_id;
        $details = Task::where('id',$id)->first();
        $status = $details->status;
        if($status == '0'){
            $newStatus = '1';
        }else if($status == '1'){
            $newStatus = '0';
        }
        $update['status'] = $newStatus;
        Task::where('id',$id)->update($update);
        echo $status;
    }
    //task end

    public function staff_list(Request $request){
        $staff = User::whereIsAdmin('0')->Where('role','!=', 3)->orderBy('id', 'DESC')->get();
        $role = Role::where('role_status', '1')->orderBy('role_id', 'DESC')->get();
        return view('admin.staff.index', compact('staff','role'));
    }

    public function create_staff(Request $request){
         $role = Role::where('role_status', '1')->orderBy('role_id', 'DESC')->get();
        return view('admin.staff.create',compact('role'));
    }

    public function store_staff(Request $request){
        $ph = $request->country_code.$request->phone;
        if (User::where('email', $request->email)->orWhere('phone', $ph)->exists()) {
          return redirect()->route('create_staff')->with('error','Mobile Number OR Email id already registrated, please check.');
        }else{

            $web_url = url('/');
            $app_url = '';
            $data = array();
            $data['name']= $request->name;
            $data['email']= $request->email;
            $data['phone']= $ph;
            $data['password']= Hash::make($request->password);
            $data['role']= $request->role;
            $data['login_status']= '1';

            $getd = User::create($data);
            $editRole = Role::where('role_id',$request->role)->first();
            $detail = [
                'subject' =>'Account Opening',
                'name' =>$request->name,
                'email' =>$request->email,
                'account_type' => $editRole->name,
                'password' => $request->password,
                'web_url' => url('/'),
                'app_url' => $app_url
            ];

            /*mail::to($request->email)->send(new VerifyMail($detail));

            $message = "Dear ".$request->name.",  Thank you for joining at our site Clindcast Time Logs.Your acccount type is : ".$editRole->name." . Email: ".$request->email." Password: ".$request->password."  Web Login: ".$web_url." App Login: ".$app_url."";

            $url = "https://elitbuzz-me.com/sms/smsapi?api_key=C200332460c9157cc64e06.85843724&type=text&contacts=" .
            $ph . "&" .
             "senderid=JWP-WiFi". "&" .
             "msg="  . urlencode($message);

            $output = file($url);*/
            return redirect()->route('staff_list')->with('success','Employee Has Been Added successfully');
        }
    }

    public function delete_staff($id){
        $category = User::where('id',$id)->delete();   
        $attendance = Attendance::where('employee_id',$id)->delete();
        return redirect()->route('staff_list');
    }

    public function edit_staff($id){
        $editstaff = User::where('id',$id)->first();
        $role = Role::where('role_status', '1')->orderBy('role_id', 'DESC')->get();
        //  dd($editstaff);
        return view('admin.staff.edit', compact('editstaff','role'));
    }

    public function assign_sites(Request $request,$id){
        $staff_info = User::where('id',$id)->first(); 
        $api_list = Allapi::where('status','1')->orderBy('id','DESC')->get();
        $sites = AccessSites::where('user_id', $id)->orderBy('id','DESC')->get();
        $sites_ids = AccessSites::select('site_id')->where('user_id', $id)->orderBy('id','DESC')->get();
        $sid = AccessSites::select("site_id")
                    ->where('user_id',$id)
                    ->get();
        $js = json_encode($sid);

        $de =   json_decode($js);
        foreach($de as $vl)
        {
            $s[] = $vl->site_id;
        }
        if(!empty($s)){
            $asign_ids =   $s;
        }else{
            $asign_ids =   '';
        }
        return view('admin.staff.assign_sites', compact('staff_info','api_list','sites','asign_ids','sid'));
    }

    public function update_assign_sites(Request $request,$id){
           
        $answers = [];
        foreach($request->site_id as $sid) {
            $answers[] = [
                'user_id' => $request->user_ids,
                'site_id' => $sid
            ];
        }
        AccessSites::insert($answers);
        return redirect()->route('assign_sites',$id)->with('success','Sites Assign successfully.');
    }

    public function delete_assign_sites($id){
        $ids = AccessSites::where('id',$id)->first();
        $rid = $ids->user_id;
        $category = AccessSites::where('id',$id)->delete();
        return redirect()->route('assign_sites',$rid);
    }

    public function update_staff(Request $request,$id){
        // if (User::where('email', $request->name)->exists()) {  
        $data = array();
        $data['name']= $request->name;
        $data['phone']= $request->phone;
        $data['password']= Hash::make($request->password);
        $data['role']= $request->role;
        User::where('id',$id)->update($data);
        return redirect()->route('staff_list')->with('success','Staff Has Been Updated successfully');
        //      }else{
        //      return redirect()->route('create_staff')->with('error','Email id already registrated, check email id.'); 
        //   }
    }

    public function change_user_status(Request $request){
        $staff_id = $request->staff_id;

        $details = User::where('id',$staff_id)->first();
        $status = $details->login_status;
        if($status == '0'){
            $newStatus = '1';
        }else if($status == '1'){
            $newStatus = '0';
        }
        $update['login_status'] = $newStatus;
        User::where('id',$staff_id)->update($update);
        echo $status;
    }

    public function role_list(Request $request){
        $role = Role::where('role_status', '1')->orderBy('role_id', 'DESC')->get();
        return view('admin.role.index', compact('role'));
    }

    public function edit_role_permission($id){
        $role = Role::where('role_id', $id)->first();
        $permissions = DB::table('permission')
            ->join('user_permissions', 'permission.permission_id', '=', 'user_permissions.permission_id')
            ->select('permission.permission_id', 'permission.name', 'permission.codename', 'user_permissions.is_create', 'user_permissions.is_edit', 'user_permissions.is_delete')
            ->where('user_permissions.role_id',$id)
            ->get();

        //$permissions = Permission::orderBy('permission_id', 'ASC')->get();
        return view('admin.role.edit', compact('role','permissions'));
    }

    public function update_role_permission(Request $request,$id){
        $user_permissions=$request->user_permissions;

        foreach($user_permissions as $id_modul => $data) {
            $arrs = array();
            $arrs['is_create'] = @$data['is_create']?:0;
            $arrs['is_edit'] = @$data['is_edit']?:0;
            $arrs['is_delete'] = @$data['is_delete']?:0;
            DB::table("user_permissions")->where('role_id',$id)->Where('permission_id', $data['permission_id'])->update($arrs);
        }
        $data = array();
        if(!empty($request->permission)){
        $data['permission']= json_encode($request->permission);
        }else{
        $data['permission']= [];
        }
        Role::where('role_id',$id)->update($data);
        return redirect()->route('role_list')->with('success','Permission Has Been Updated successfully');
    }

    public function registered_user_list(Request $request){
        $registered_user_list = RegisteredUser::orderBy('id', 'DESC')->get();
        return view('admin.registered_user_list', compact('registered_user_list'));
    }

    public function create_role(Request $request){
        return view('admin.staff.createrole');
    }

    public function store_role(Request $request){
        if (Role::where('name', $request->name)->exists()) {   
          return redirect()->route('create_role')->with('error','Role already registrated, please check.'); 
        }else{
            $data = array();
            $data['name']= $request->name;
            $data['description']= $request->description;
            $data['role_status']= $request->role_status;
            $getd= Role::create($data);

            $id = $getd->id;

            $permissions = Permission::get();
            foreach($permissions as $permission){
                Userpermission::create(['role_id'=> $id,'permission_id'=> $permission->permission_id ]);
            }

            return redirect()->route('role_lists')->with('success','Role Has Been Added successfully');
        }
    }

    public function role_lists(Request $request){
        $roles = Role::orderBy('role_id', 'DESC')->get();
        return view('admin.staff.role_list', compact('roles'));
    }

    public function delete_role($id){
        Role::where('role_id',$id)->delete();
        return redirect()->route('role_lists');
    }

    public function edit_roles($id){
        $role = Role::where('role_id',$id)->first();
        return view('admin.staff.edit_role', compact('role','role'));
    }

    public function update_roles(Request $request,$id){
        $data = array();
        $data['name']= $request->name;
        $data['description']= $request->description;
        $data['role_status']= $request->role_status;
        Role::where('role_id',$id)->update($data);
        return redirect()->route('role_lists')->with('success','Role Has Been Updated successfully');
    }

    public function permission_lists(Request $request){
        $permissions = Permission::orderBy('permission_id', 'DESC')->get();
        return view('admin.permission.list', compact('permissions'));
    }

    public function create_permission(Request $request){
        return view('admin.permission.create');
    }

    public function store_permission(Request $request){
        if (Permission::where('name', $request->name)->exists()) {
          return redirect()->route('create_role')->with('error','Permission already registrated, please check.');
        }else{
            $data = array();
            $data['name']= $request->name;
            $data['description']= $request->description;
            $data['codename']= $request->codename;
            Role::create($data);
            return redirect()->route('permission_lists')->with('success','Permission Has Been Added successfully');
        }
    }

}