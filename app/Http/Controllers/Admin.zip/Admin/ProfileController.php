<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Admin\Http;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Role;
use App\Models\Permission;
use App\Models\Attendance;
use App\Models\Holiday;
use App\Models\Attendanceday;
use App\Models\ActivityNotification;
use App\Models\RegisteredUser;
use Hash;
use Auth;
use DateTime;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
class ProfileController extends Controller
{
    public function dashboards(){
        $user_id = Auth::user()->id;
        $admin_role = Auth::user()->role;
        $data=[
            'title'=>'Dashboard'
        ];
        
        if($admin_role == '1'){
          
            //$payment_adjustment = PaymentCollect::where('payment_adjustment','1')->where('month',date('m'))->where('year',date('Y'))->sum('cash_received');
           
            //$total_site_payments = SitePaymentTotal::where('month',date('m'))->where('year',date('Y'))->where('status','1')->sum('total_amount');
            //  dd($total_site_payments);
            //$cash_received = PaymentCollect::where('payment_adjustment','0')->where('month',date('m'))->where('year',date('Y'))->sum('cash_received');
            //$total_sales_voucher_report = SaleReportCreateVoucher::where('status','success')->sum('price');
            //$cash_due = PaymentCollect::sum('cash_due');
            // $api_active_count = Allapi::where('status','1')->get()->count();
            // $api_deactive_count = Allapi::where('status','0')->get()->count();
            $total_staff = User::where('role_status','1')->Where('role','!=', 3)->get()->count();
            $total_employee = User::where('role_status','1')->Where('role', 3)->get()->count();
            // $payment_collect_count = PaymentCollect::where('payment_adjustment','0')->where('month',date('m'))->where('year',date('Y'))->get()->count();
            // $today_sale = Sale::where('status','1')->get()->sum('sale');
            // $monthly_sale = MonthlySale::where('status','1')->whereMonth('date', date('m'))->whereYear('date', date('Y'))->get()->sum('sale');
            // $api_list = Allapi::where('status','1')->orderBy('id','DESC')->get();
            $todayattendance = Attendance::where('month',date('m'))->where('year',date('Y'))->get();
            $total_attd = $todayattendance->count();
            /*$collect_monthly_amount_list = PaymentCollect::select(DB::raw("SUM(cash_received) as count"))
                ->where('graph', '0')
                ->whereYear('date', date('Y'))
                ->groupBy(DB::raw("Month(date)"))
                ->pluck('count');*/
            return view('admin.dashboard',$data,compact('total_staff','total_employee','total_attd'));
        }else{

            // $cash_received = PaymentCollect::where('employee_id',$user_id)->sum('cash_received');
            // $cash_due = PaymentCollect::where('employee_id',$user_id)->sum('cash_due');
            // $api_active_count = Allapi::where('status','1')->get()->count();
            // $api_deactive_count = Allapi::where('status','0')->get()->count();
            $total_staff = User::where('role_status','1')->get()->count();
            // $today_sale = Sale::where('status','1')->get()->sum('sale');
            // $monthly_sale = MonthlySale::where('status','1')->whereMonth('date', date('m'))->whereYear('date', date('Y'))->get()->sum('sale');
            // $api_list = Allapi::where('status','1')->orderBy('id','DESC')->get();
            $todayattendance = Attendance::where('employee_id',$user_id)->where('date',date('Y-m-d'))->first();
            $count_att = Attendance::where('employee_id',$user_id)->where('year',date('Y'))->where('month',date('m'))->get();
            //$total_sales_voucher_report = SaleReportCreateVoucher::where('user_id',$user_id)->where('status','success')->sum('price');
            $count_employee_present = $count_att->count();
            $month = date('m');
            $year = date('Y');
            $total_day_in_month = date('d');
            $holiday  = Holiday::where('month',$month)->where('year',$year)->where('created_at','<=',date("Y-m-d"))->count('id');
            $total_day = $total_day_in_month - $holiday;

            $present  = Attendance::where('employee_id',$user_id)->where('month',$month)->where('year',$year)->count('id');
            $absent = $total_day - $present;
            if($absent < 0){
                $absent =0;
            }
            return view('admin.dashboard',$data,compact('total_staff','todayattendance','count_employee_present','present','absent'));
        }
    }
    
    public function dashboard_demo(){
        $user_id = Auth::user()->id;
        // $api_active_count = Allapi::where('status','1')->get()->count();
        // $api_deactive_count = Allapi::where('status','0')->get()->count();
        $total_staff = User::where('role_status','1')->get()->count();
        // $today_sale = Sale::where('status','1')->get()->sum('sale');
        // $monthly_sale = MonthlySale::where('status','1')->whereMonth('date', date('m'))->whereYear('date', date('Y'))->get()->sum('sale');
        // $api_list = Allapi::where('status','1')->orderBy('id','DESC')->get();
        $todayattendance = Attendance::where('date',date('Y-m-d'))->first();
        return view('admin.dashboard1',compact('total_staff','todayattendance'));
    }

    public function profile(){
        $user_id = Auth::user()->id;
        $profile = User::where('id',$user_id)->first();
        return view('admin.profile',compact('profile'));
    }

    public function update_profile(Request $request, $id){

        $request->validate([
            'name' => 'required',
            'email' => 'required|email',
            'phone' => 'required',
        ]);
        $data1 = array();
        if($request->hasFile('banner')) {
            $img_ext = $request->file('banner')->getClientOriginalExtension();
            $filename = 'profile_photo-' . time() . '.' . $img_ext;
            $path = $request->file('banner')->move(public_path('admin/backend/user_profile'), $filename);//image save public folder
            $data1['image']= $filename;
            $data1['image_url'] = url('admin/backend/user_profile/'.$filename);
        }
        $data1['name']= $request->name;
        $data1['email'] = $request->email;
        $data1['phone'] = $request->phone;

        if($request->new_password != null && ($request->new_password == $request->confirm_password)){
            $data1['password']= Hash::make($request->new_password);
        }

        $query_insert = User::where('id',$id)->update($data1);
        return redirect()->route('profile')->with('success','Profile Has Been updated successfully');
    }

    public function logout(){
        auth()->logout();
        return redirect()->route('getLogin')->with('success','You have been successfully logged out');
    }

    /*public function recharge_list(){
        //   $url = "http://jwp208.dyndns.info:88/api/sale";
        //   $ch = curl_init();
        //   curl_setopt($ch, CURLOPT_URL, $url);
        //   curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        //   $result = curl_exec($ch);
        //   $getlist = $result;
        //   $show_list = json_decode($getlist,true);
        //   dd($getlist);
        $api_list = Allapi::where('status','1')->where('type','2')->orderBy('id','DESC')->get();
        // dd($api_list);
        return view('admin.recharge_report.index',compact('api_list'));
    }
    
    
    public function store_today_sale()
    {
        $data = array();
        $data1 = array();
        $api_list = Allapi::where('status','1')->where('type','2')->orderBy('id','DESC')->get();
        foreach($api_list as $info){
            $url = $info->api_url;
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            $result = curl_exec($ch);
            $getlist = $result;
            $show_list = json_decode($getlist,true);
            if(!empty($show_list)){
                foreach($show_list as $list){
                    $data['name']= $info->name;
                    $data['sale']= $list['sale'];
                    $data['date']= $list['date'];
                }
                if (Sale::where('name', $info->name)->exists()) {
                    $data1['sale']= $list['sale'];
                    $data1['date']= $list['date'];
                    Sale::where('name', $info->name)->update($data1);
                }else{
                    Sale::create($data);
                } 
            }
        }
    }

    public function store_monthly_sale()
    {
        $from_date = date("Y-m-d", strtotime("first day of this month"));
        $to_date = date("Y-m-d", strtotime("last day of this month"));

        $data = array();
        $data1 = array();
        $api_list = Allapi::where('status','1')->where('type','2')->orderBy('id','DESC')->get();
        foreach($api_list as $info){
            //$from_date = date("Y-m-d", strtotime("first day of previous month"));
            //$to_date = date("Y-m-d", strtotime("last day of previous month"));
            $from_to = '?from='.$from_date.'&to='.$to_date;
            $url = $info->api_url.$from_to;
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            $result = curl_exec($ch);
            $getlist = $result;
            $show_list = json_decode($getlist,true);
            if(!empty($show_list)){
                foreach($show_list as $list){
                    $data['name']= $info->name;
                    $data['sale']= $list['sale'];
                    $data['date']= $list['date'];
                }
                if (MonthlySale::where(['name' => $info->name,'date' => $list['date']])->exists()) {
                    // your code...
                    // Sale::create($data);
                    $data1['sale']= $list['sale'];
                    MonthlySale::where(['name' => $info->name,'date' => $list['date']])->update($data1);
                }else{
                    MonthlySale::create($data);
                    // Sale::where('date',$list['date'])->update($data);
                } 
            }
        }
    }*/
    
    function admin_permission($codename)
    {
        $admin_id = Auth::user()->id;
        $admin = User::where('id',$admin_id)->first();
        $permission_obj = Permission::where('codename',$codename)->first();
        $permission = $permission_obj != null && isset($permission_obj->permission_id) ? $permission_obj->permission_id : 0;
        if ($admin->role == 1) {
            return true;
        } else {
            $role = $admin->role;
            $role_p = Role::select('permission')->where('role_id',$role)->first();
            $role_permissions = json_decode($role_p);
            if (in_array($permission, $role_permissions)) {
                return true;
            } else {
                return false;
            }
        }
    }
    /*
    public function recharge_history(Request $request){     
       $recharge_history = Allapi::where('status','1')->where('type','2')->orderBy('id','DESC')->get();
        return view('admin.recharge_report.recharge_history',compact('recharge_history'));
    }

    public function search_history(Request $request){

        $from_date = $request->start_date;
        $to_date = $request->end_date;
        $name = $request->site_name;
        if(!empty($name) && !empty($from_date) && !empty($to_date)){
            $api_list = Allapi::where('status','1')->where('type','2')->where('id',$name)->first();
            //  dd($api_list);
            //  foreach($api_list as $info){
            $from_to = '?from='.$from_date.'&to='.$to_date.'&group=day';
            $url = $api_list->api_url.$from_to;
            //   dd($url);
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            $result = curl_exec($ch);
            $getlist = $result;
            $show_list = json_decode($getlist,true);
            //  }
        }
        $recharge_history = Allapi::where('status','1')->where('type','2')->orderBy('id','DESC')->get();
        return view('admin.recharge_report.recharge_history',compact('recharge_history','show_list','name','to_date','from_date'));
    }

    //  new api
    public function new_recharge_history(Request $request){

       $new_recharge_history = Allapi::where('status','1')->orderBy('id','DESC')->get();
        return view('admin.recharge_report.new_recharge_history',compact('new_recharge_history'));
    } 

    public function view_site_details(Request $request,$id){
         
        if ($request->start_date != null && $request->end_date != null) {
            $f_day = $request->start_date;      
            $l_day = $request->end_date;  
            $id_d = Allapi::where('id',$id)->first();
            if($id_d->type == '1'){

            $token  = substr(md5(date('YMD', strtotime('today')).'chaman'), 0, 12);
            $datebetween = $token.'/'.$f_day.'/'.$l_day;
            $url_new = $id_d->api_url.'/'.$datebetween;
            $client = new \GuzzleHttp\Client();
            $response = $client->request('GET', $url_new);

            $statusCode = $response->getStatusCode();
            $show_site_details1 = json_decode($response->getBody(), true);
            return view('admin.recharge_report.view_site_details',compact('show_site_details1','f_day','l_day'));
            }else if($id_d->type == '2'){

                $from_to = '?from='.$f_day.'&to='.$l_day.'&group=day';
                $url = $id_d->api_url.$from_to;
                //   dd($url);
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                $result4 = curl_exec($ch);
                $getlist4 = $result4;
                $show_site_details2 = json_decode($getlist4,true);  
                return view('admin.recharge_report.view_site_details',compact('show_site_details2','f_day','l_day'));
            }
        }else{
            
            $id_d = Allapi::where('id',$id)->first();
            $f_day = date('Y-m-d', strtotime('first day of this month'));
            $l_day = date('Y-m-d');
            // dd($l_day);
            $token  = substr(md5(date('YMD', strtotime('today')).'chaman'), 0, 12);
            $datebetween = $token.'/'.$f_day.'/'.$l_day;
            $url_new = $id_d->api_url.'/'.$datebetween;
            $client = new \GuzzleHttp\Client();
            $response = $client->request('GET', $url_new);

            $statusCode = $response->getStatusCode();
            $show_site_details1 = json_decode($response->getBody(), true);
            $from_to = '?from='.$f_day.'&to='.$l_day.'&group=day';
            $url2 = $id_d->api_url.$from_to;
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url2);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            $result2 = curl_exec($ch);
            $getlist2 = $result2;
            $show_site_details2 = json_decode($getlist2,true);
            //   dd($show_site_details2);
            return view('admin.recharge_report.view_site_details',compact('show_site_details1','show_site_details2','f_day','l_day'));
        }
    }
    // end new api

    //offline api details by amar sir
    public function offline_recharge_history(Request $request){
        //   $new_recharge_history = Allapi::where('status','1')->where('type','1')->orderBy('id','DESC')->get();
        $new_recharge_history = Allapi::where('status','1')->orderBy('id','DESC')->get();
        return view('admin.recharge_report.offline_recharge_history',compact('new_recharge_history'));
    } 
    
    public function view_offline_site_details(Request $request,$id){

        if ($request->start_date != null && $request->end_date != null) {
            $f_day = $request->start_date;      
            $l_day = $request->end_date;  
            $show_site_details = Newapidata::where('site_name',$id)->where('activation_date', '>=',$f_day)->where('activation_date', '<=',$l_day)->orderBy('activation_date','ASC')->get();
            $api_name = Allapi::where('name',$id)->first();
        }else{
            
            $f_day = $request->start_date;      
            $l_day = $request->end_date;  
            $show_site_details = Newapidata::where('site_name',$id)->orderBy('activation_date','ASC')->get();
            $api_name = Allapi::where('name',$id)->first();
        }
        return view('admin.recharge_report.view_offline_site_details',compact('api_name','show_site_details','f_day','l_day'));
    }*/
    //end offline api

    public function storeattendance(Request $request)
    {
        $office_time = '10:00:00';
        $request->validate([
            'working_from' => 'required',
        ]);
        $user_id = Auth::user()->id;
        if (Attendance::where(['employee_id' => $user_id,'date' => date('Y-m-d')])->exists()) {
            return redirect()->route('dashboards')->with('error','Today you had already use clock-in to clock-out.');
        }else{
            $data = array();
            $data['employee_id']= $user_id;
            $data['working_from']= $request->working_from;
            $data['mark_attendance_by']= '1';
            $data['date']= date('Y-m-d');
            $data['day']= date('d');
            $data['month']= date('m');
            $data['year']= date('Y');
            $data['live_location']= $request->live_location;
            $data['clock_in']= date('H:i:s');
            if($office_time < date('H:i:s')){
                $data['late']= 'Yes';
            }else{
                $data['late']= 'No'; 
            }

            Attendance::create($data);
            $data1['user_id']= Auth::user()->id;
            $data1['user_type']= Auth::user()->role;
            $data1['module']= 'Attendance';
            $data1['activity']= 'Clock In';
            $data1['status']= 'unread';
            ActivityNotification::create($data1);
            return redirect()->route('dashboards')->with('success','Attendance saved successfully');
        }
    }

    public function checkoutattendance(Request $request, $id)
    {
        $get_d =  Attendance::where('id',$id)->first(); 

        $time1 = new DateTime($get_d->clock_in);
        //   dd($time1);
        $time2 = new DateTime(date('H:i:s'));
        $time_diff = $time1->diff($time2);
        $hourss = $time_diff->h;
        $user_id = Auth::user()->id;
        $data = array();
        $data['clock_out']= date('H:i:s');
        $data['total_hours']= $hourss;
        if(!empty($request->live_location)){
            $data['clock_out_location']= $request->live_location;
        }
        $data['status']= '0';
    
        Attendance::where('employee_id',$user_id)->where('id',$id)->update($data);
        $data1['user_id']= Auth::user()->id;
        $data1['user_type']= Auth::user()->role;
        $data1['module']= 'Attendance';
        $data1['activity']= 'Clock Out';
        $data1['status']= 'unread';
        ActivityNotification::create($data1);
        return redirect()->route('dashboards')->with('success','Check out time saved successfully');
    }

    public function daystart(Request $request)
    {
        $user_id = Auth::user()->id;
        $data = array();
        $data['employee_id']= $user_id;
        $data['mark_attendance_by']= '1';
        $data['date']= date('Y-m-d');
        $data['day']= date('d');
        $data['month']= date('m');
        $data['year']= date('Y');
        $data['clock_in']= date('H:i:s');

        $getd = Attendanceday::create($data);

        $data1['user_id']= Auth::user()->id;
        $data1['user_type']= Auth::user()->role;
        $data1['module']= 'Attendance';
        $data1['activity']= 'Break Start';
        $data1['status']= 'unread';
        ActivityNotification::create($data1);
        print($getd->id);
    }

    public function dayend(Request $request)
    {
        $get_d =  Attendanceday::where('id',$request->id)->first(); 
        $time1 = new DateTime($get_d->clock_in);
        $time2 = new DateTime(date('H:i:s'));
        $time_diff = $time1->diff($time2);
        $seconds = $time_diff->days * 24 * 60 * 60;
        $seconds += $time_diff->h * 60 * 60;
        $seconds += $time_diff->i * 60;
        $seconds += $time_diff->s;
        $hourss =$seconds; 
        $user_id = Auth::user()->id;
        $data = array();
        $data['clock_out']= date('H:i:s');
        $data['total_hours']= $hourss;
        $data['status']= '0';
    
        Attendanceday::where('employee_id',$user_id)->where('id',$request->id)->update($data);
        $data1['user_id']= Auth::user()->id;
        $data1['user_type']= Auth::user()->role;
        $data1['module']= 'Attendance';
        $data1['activity']= 'Break End';
        $data1['status']= 'unread';
        ActivityNotification::create($data1);
    }

    public function reports(){
        $user_id = Auth::user()->id;
        $data = Attendanceday::where('employee_id',$user_id)->whereDate('date', '=', date('Y-m-d'))->get();
        return view('admin.report.index', compact('data'));
    }

    public function attendencelist(){
        if(Attendanceday::count()>0){
            $data = Attendanceday::select('*', DB::raw('sum(total_hours) as total_hours'))->groupBy('date', 'employee_id')->get();
        }else{
            $data = Attendanceday::get();
        }
        $user = User::get();
        return view('admin.report.indexadmin', compact('data','user'));
    }

    public function attendencedetail($id,$date){
        $data = Attendanceday::where('employee_id',$id)->whereDate('date', '=', $date)->get();
        return view('admin.report.index', compact('data'));
    }

}