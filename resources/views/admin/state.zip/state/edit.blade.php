@extends('admin.layout')
@section('content')
    <div class="container-fluid">
        <!-- Page Heading -->
        <div class="row">
            <div class="col-md-10">
                <h1 class="h3 mb-2 text-gray-800">Edit State Registry</h1>
            </div>
            <div class="col-md-2">
                <a href="{{ route('state_lists') }}" class="btn btn-dark btn-icon-split">
                    <span class="text">Back</span>
                </a>
            </div>
        </div>
        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <!--<div class="card-header py-3">-->
            <!--    <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6>-->
            <!--</div>-->
            <div class="card-body">
                @if(session('error'))
                    <div class="alert alert-custom alert-indicator-top indicator-danger" role="alert">
                        <div class="alert-content">
                            <span class="alert-title">Error!</span>
                            <span class="alert-text"> {{ session('error') }}</span>
                        </div>
                    </div>
                @endif
                <div class="row">
                    <div class="col-md-12">
                        <div class="col-md-3">
                        </div>
                        <div class="col-md-9">
                            <form action="{{ route('update_state',$editstate->id) }}" method="post" enctype="multipart/form-data">
                                @csrf
                                <div class="row mb-3">
                                    <label class="col-sm-3 col-form-label required">State Name</label>
                                    <div class="col-sm-9">
                                        <input type="text" name="name" value="{{ $editstate->name }}" placeholder="PBM Name" class="form-control" required>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label class="col-sm-3 col-form-label required">SIU</label>
                                    <div class="col-sm-9">
                                        <input type="text" name="siu" value="{{ $editstate->siu }}" placeholder="SIU" class="form-control" required>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label class="col-sm-3 col-form-label required">SU</label>
                                    <div class="col-sm-9">
                                        <input type="text" name="su" value="{{ $editstate->su }}" placeholder="SU" class="form-control" required>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label class="col-sm-3 col-form-label required">Website</label>
                                    <div class="col-sm-9">
                                        <input type="text" name="website" value="{{ $editstate->website }}" placeholder="Website" class="form-control" required>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label class="col-sm-3 col-form-label required">User Name</label>
                                    <div class="col-sm-9">
                                        <input type="text" name="user_name"  placeholder="User Name" value="{{ $editstate->user_name }}"  class="form-control" required>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label class="col-sm-3 col-form-label required">Password</label>
                                    <div class="col-sm-8">
                                        <input type="password" id="password" name="password" value="{{ $editstate->password }}"  placeholder="Password" class="form-control" required>
                                    </div>
                                    <div class="col-sm-1 input-group-text"><i class="fas fa-eye-slash" id="eye"></i></div>
                                </div>
                                <div class="row mb-3">
                                    <label class="col-sm-3 col-form-label required">Comments</label>
                                    <div class="col-sm-9">
                                        <input type="textarea" name="comments" value="{{ $editstate->comments }}" placeholder="Comments" class="form-control">
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label  class="col-sm-3 col-form-label">Update</label>
                                    <div class="col-sm-9">
                                        <input type="text" name="updates" value="{{ $editstate->updates }}" placeholder="Update" class="form-control">
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label class="col-sm-3 col-form-label required">Next Task</label>
                                    <div class="col-sm-9">
                                        <input type="text" name="next_task" value="{{ $editstate->next_task }}" placeholder="Next Task" class="form-control" required>
                                    </div>
                                </div>
                                <input type="submit" class="btn btn-primary" value="Update">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <style type="text/css">
        i{
            cursor:pointer;
        }
        .required:after {
            content:" *";
            color: red;
          }
    </style>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
    <script>
    $(function(){
  
          $('#eye').click(function(){
               
                if($(this).hasClass('fa-eye-slash')){
                   
                  $(this).removeClass('fa-eye-slash');
                  
                  $(this).addClass('fa-eye');
                  
                  $('#password').attr('type','text');
                    
                }else{
                 
                  $(this).removeClass('fa-eye');
                  
                  $(this).addClass('fa-eye-slash');  
                  
                  $('#password').attr('type','password');
                }
            });
        });
        $("#user_id").select2({
          placeholder: "Select",
          allowClear: true,
      });
    </script>
@endsection