@extends('admin.layout')
@section('content')
    <div class="container-fluid _dashboard-style">
       <!--  @if(session('success'))
            <div class="alert alert-success" role="alert">
                {{ session('success') }}
            </div>
        @endif
        @if(session('error'))
            <div class="alert alert-danger" role="alert">
                {{ session('error') }}
            </div>
        @endif -->
        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between _employee-deshboard _title-style">
            @if(!empty($todayattendance->status) && $todayattendance->status == '1')
                <div class="col-md-7">
                    <h1 class="h3 mb-0 text-gray-800">Welcome to @if(Auth::user()->name) {{ Auth::user()->name }} @endif</h1>
                </div>
                <div class="col-md-3"> &nbsp;&nbsp;&nbsp;
                    <b> @php echo date('h:i a'); @endphp</b>
                    <br>
                    <!-- <p>Clock In at - {{ date('h:i a',strtotime($todayattendance->clock_in)) }}</p> -->
                </div>
            @else
                <div class="col-md-8">
                    <h1 class="h3 mb-0 text-gray-800">Welcome to @if(Auth::user()->name) {{ Auth::user()->name }} @endif @if(Auth::user()->last_name) {{ Auth::user()->last_name }} @endif </h1>
                </div>
                <div class="col-md-2"> &nbsp;&nbsp;&nbsp;
                    <b> @php echo date('h:i a'); @endphp</b>
                </div>
            @endif
            <!-- <div class="col-md-2">  -->
                @if(Auth::user()->role != 12)
                    @if(!empty($todayattendance->status) &&  $todayattendance->status == '1')
                        <!--<a onclick="if (!confirm('Are you sure? you want to check out'))-->
                        <!--return false;" href="{{ route('checkoutattendance',$todayattendance->id) }}" class="d-none d-sm-inline-block btn btn-danger shadow-sm"><i-->
                        <!--class="fas fa-sign-out-alt text-white"></i> Clock Out</a>-->
                        <!-- <button type="button" class="d-none d-sm-inline-block btn btn-primary shadow-sm" data-toggle="modal" data-target="#myModal_clockout">
                            <i class="fas fa-sign-out-alt text-white"></i> Clock Out</a>
                        </button> -->
                    @else
                       <!-- <button type="button" class="d-none d-sm-inline-block btn btn-primary shadow-sm" data-toggle="modal" data-target="#myModal">
                        <i class="fas fa-sign-in-alt text-white"></i> Clock In</button> -->
                    @endif
                @endif
            <!-- </div> -->
        </div>
        <!-- Content Row -->
        <div class="row _icon-box">
            <!-- <div class="col-md-12 mb-4">
                <div class="row">
                    <div class="col-md-12 mb-4">
                        <div class="card border-left-info shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                            Time Entry
                                        </div>
                                    </div>
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                           <b class="entry"> @php echo date('m/d/y'); @endphp</b>
                                        </div>
                                    </div>
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                            <b class="entry">Working Hours</b>
                                        </div>
                                    </div>
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                            <time class="entry1" id="timer">00:00:00</time>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-12 mb-4">
                <div class="row">
                    <div class="col-md-12 mb-4">
                        <div class="card border-left-info shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                            <button id="daystart" onclick="dayStart();" class="btn btn-primary dash">Login</button>
                                        </div>
                                    </div>
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                            <button class="btn btn-primary dash" onclick="dayEnd();" id="breakstart">Break Start</button>
                                        </div>
                                    </div>
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                            <button class="btn btn-primary dash" onclick="dayStart();" id="breakend">Break End</button>
                                        </div>
                                    </div>
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                            <button class="btn btn-primary dash" onclick="dayEnd();" id="dayend">Logout</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> -->
            <!-- <div class="col-md-12">
                <div class="row">
                    <div class="col-md-3 mb-4">
                        <div class="card border-left-success shadow h-100 py-2">
                            <div class="card-body _user-detl">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="col-md-3" style="float: left;padding-right:5px; padding-left:5px; ">
                                            @php  $emp = App\Models\User::where('id',Auth::user()->id)->first(); @endphp
                                            @if(!empty($emp->image_url))
                                             <img class="img-profile" src="{{ $emp->image_url }}" style="width: 100%;">
                                             @else
                                             <img class="img-profile" src="{{ asset('admin/assets/img/undraw_profile.svg') }}" style="width: 50px;">
                                             @endif
                                        </div>
                                        <div class="col-md-9"  style="float: left;">
                                           <h4 style="    font-size: 1.4rem;"><b>@if(Auth::user()->name) {{ Auth::user()->name }} @endif</b></h4>
                                           <p>Employee ID : EMP-1</p>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-money-bill fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-4">
                        <div class="card border-left-primary shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Present</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                                           {{ $present ?? '0' }}</div>
                                    </div>
                                    <div class="col-auto _icon-br">
                                        <i class="fas fa-check"></i>
                                        <a href="{{ route('attendance.index') }}" class="text-blue-300 d-none d-sm-inline-block btn btn-primary shadow-sm" style="background-color:#2e4fb19e;width: 54px;font-size: 12px;height: 32px;">View</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-4">
                        <div class="card border-left-info shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Absent</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800">{{ $absent ?? '0' }}
                                        </div>
                                    </div>
                                    <div class="col-auto _icon-br">
                                        <i class="fas fa-times"></i>
                                        <a href="{{ route('attendance.index') }}" class="text-blue-300 d-none d-sm-inline-block btn btn-primary shadow-sm" style="background-color:#2e4fb19e;width: 54px;font-size: 12px;height: 32px;">View</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> -->
        </div>


        <!--test -->
        <div class="_icon-box">
            <div class="col-md-12">
                <div class="row">
                    <div class="col-md-3 mb-4">
                        <div class="card border-left-info shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                            Time Entry</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-4">
                        <div class="card border-left-warning shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                            <b class="entry"> @php echo date('m/d/y'); @endphp</b></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-4">
                        <div class="card border-left-warning shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                            <b class="entry">Working Hours</b></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-4">
                        <div class="card border-left-warning shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                            <time class="entry1" id="timer">00:00:00</time></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- test1 -->
        <div class="_icon-box">
            <div class="col-md-12">
                <div class="row">
                    <div class="col-md-3 mb-4">
                        <div class="card border-left-info shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                            <button id="daystart" onclick="dayStart();" class="btn btn-primary dash">Login</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-4">
                        <div class="card border-left-warning shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                            <button class="btn btn-primary dash" onclick="dayEnd();" id="breakstart">Break Start</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-4">
                        <div class="card border-left-warning shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                            <button class="btn btn-primary dash" onclick="dayStart();" id="breakend">Break End</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-4">
                        <div class="card border-left-warning shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                            <button class="btn btn-primary dash" onclick="dayEnd();" id="dayend">Logout</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- test -->
    </div>
    {{ csrf_field() }}
    <style>
        .dash{
            padding: 10px 30px 10px 30px;
        }
        .entry{
            color: #fff !important;
            background-color: #007bff !important;
            padding: 30px 30px 30px 30px !important;
        }
        .entry1{
            color: #fff !important;
            background-color: #ff6f00 !important;
            padding: 30px 30px 30px 30px !important;
        }
    </style>
    <script src="{{ asset('admin/assets/vendor/jquery/jquery.min.js') }}"></script>
    <script type="text/javascript">
        /*(function timer() {
            'use strict';
            //declare
            var output = document.getElementById('timer');
            var toggle = document.getElementById('daystart');
            var pause = document.getElementById('breakstart');
            var resum = document.getElementById('breakend');
            var dayend = document.getElementById('dayend');
            var running = false;
            var paused = false;
            var timer;

            // timer start time
            var then;
            // pause duration
            var delay;
            // pause start time
            var delayThen;

            // start timer
            var start = function() {
                delay = 0;
                running = true;
                then = Date.now();
                timer = setInterval(run,51);
                //toggle.innerHTML = 'stop';
                $('#daystart').attr('disabled',true);
                $('#breakstart').attr('disabled',false);
                $('#dayend').attr('disabled',false);
            };

            // parse time in ms for output
            var parseTime = function(elapsed) {
                // array of time multiples [hours, min, sec, decimal]
                var d = [3600000,60000,1000,10];
                var time = [];
                var i = 0;

                while (i < d.length) {
                    var t = Math.floor(elapsed/d[i]);

                    // remove parsed time for next iteration
                    elapsed -= t*d[i];

                    // add '0' prefix to m,s,d when needed
                    t = (i > 0 && t < 10) ? '0' + t : t;
                    time.push(t);
                    i++;
                }
                return time;
            };

            // run
            var run = function() {
                // get output array and print
                var time = parseTime(Date.now()-then-delay);
                output.innerHTML = time[0] + ':' + time[1] + ':' + time[2] ;
            };

            // stop
            var stop = function() {
                paused = true;
                delayThen = Date.now();
                //toggle.innerHTML = 'resume';
                $('#breakstart').attr('disabled',true);
                $('#breakend').attr('disabled',false);
                $('#dayend').attr('disabled',true);
                //clear.dataset.state = 'visible';
                clearInterval(timer);
                // call one last time to print exact time
                run();
            };

            // resume
            var resume = function() {
                paused = false;
                delay += Date.now()-delayThen;
                timer = setInterval(run,51);
                //toggle.innerHTML = 'stop';
                $('#breakend').attr('disabled',true);
                $('#breakstart').attr('disabled',false);
                $('#dayend').attr('disabled',false);
                //clear.dataset.state = '';
            };

            // clear
            var reset = function() {
                running = false;
                paused = false;
                //toggle.innerHTML = 'start';
                output.innerHTML = '0:00:00.00';
                //clear.dataset.state = '';
            };

            // evaluate and route
            var router = function() {
                if (!running) start();
                else if (paused) resume();
                else stop();
            };

            var end = function() {
                if (running) stop();
                $('#daystart').attr('disabled',true);
                $('#breakstart').attr('disabled',true);
                $('#breakend').attr('disabled',true);
                $('#dayend').attr('disabled',true);
            };
            
            toggle.addEventListener('click',router);
            pause.addEventListener('click',router);
            resum.addEventListener('click',resume);
            dayend.addEventListener('click',end);

        })();*/

        jQuery(document).ready(function($){
            // $('#breakstart').attr('disabled',true);
            // $('#breakend').attr('disabled',true);
            // $('#dayend').attr('disabled',true);
        });

        function dayStart() {
            var _token = $('input[name="_token"]').val();
            var daystart = 'daystart';
            $.ajax({
                url: "{{ route('daystart') }}",
                method: 'POST',
                data:{ daystart:daystart, _token:_token},
                success: function(data) {
                    localStorage.setItem('attendance_id', data);
                } 
            });
        }

        function dayEnd() {
            var _token = $('input[name="_token"]').val();
            var id = parseInt(localStorage.getItem('attendance_id'));
            $.ajax({
                url: "{{ route('dayend') }}",
                method: 'POST',
                data:{ id:id, _token:_token},
                success: function(data) {
                    localStorage.removeItem('attendance_id');
                } 
            });
        }

        var timer;
        var startTime;
        var breakstartTime;
        var breakendTime;
        var time;

        var stopBtn = document.getElementById('breakstart');
        var toggle = document.getElementById('daystart');
        var pause = document.getElementById('breakstart');
        var resum = document.getElementById('breakend');
        var dayend = document.getElementById('dayend');

        function start() {
            $('#daystart').attr('disabled',true);
            $('#breakstart').attr('disabled',false);
            $('#breakend').attr('disabled',true);
            $('#dayend').attr('disabled',false);
            startTime = parseInt(localStorage.getItem('startTime') || Date.now());
            localStorage.setItem('startTime', startTime);
            timer = setInterval(clockTick, 100);
        }

        function stop() {
            clearInterval(timer);
            var time =  $("#timer").html();
            localStorage.setItem('time', time);
            localStorage.removeItem('breakstartTime');
            breakstartTime = parseInt(localStorage.getItem('breakstartTime') || Date.now());
            localStorage.setItem('breakstartTime', breakstartTime);
            clearInterval(timer);
            $('#breakstart').attr('disabled',true);
            $('#breakend').attr('disabled',false);
            $('#dayend').attr('disabled',true);
        }

        function reset() {
            clearInterval(timer);
            localStorage.removeItem('startTime');
            document.getElementById('timer').innerHTML = "00:00:00";
        }

        function resume(){
            $('#breakend').attr('disabled',true);
            $('#breakstart').attr('disabled',false);
            $('#dayend').attr('disabled',false);
            breakstopTime = parseInt(localStorage.getItem('breakstopTime') || Date.now());
            breakstartTime = parseInt(localStorage.getItem('breakstartTime'));
            startTime = parseInt(localStorage.getItem('startTime'));
            diff = breakstopTime-breakstartTime;
            startTime = startTime+diff;
            localStorage.setItem('startTime', startTime);
            localStorage.removeItem('breakstopTime');
            localStorage.removeItem('breakstartTime');
            timer = setInterval(clockTick, 100);
        }

        function clockTick() {
            var currentTime = Date.now(),
                timeElapsed = new Date(currentTime - startTime),
                hours = timeElapsed.getUTCHours(),
                mins = timeElapsed.getUTCMinutes(),
                secs = timeElapsed.getUTCSeconds(),
                ms = timeElapsed.getUTCMilliseconds(),
                display = document.getElementById("timer");

            display.innerHTML =
                (hours > 9 ? hours : "0" + hours) + ":" +
                (mins > 9 ? mins : "0" + mins) + ":" +
                (secs > 9 ? secs : "0" + secs);
        };

        toggle.addEventListener('click', function() {
            start();
        })

        stopBtn.addEventListener('click', function() {
            stop();
        })

        resum.addEventListener('click', function() {
            resume();
        })

        dayend.addEventListener('click', function() {
            stop();
            localStorage.removeItem('startTime', startTime);
            localStorage.removeItem('breakstopTime');
            localStorage.removeItem('breakstartTime');
            localStorage.removeItem('time');
            $('#daystart').attr('disabled',true);
            $('#breakstart').attr('disabled',true);
            $('#breakend').attr('disabled',true);
            $('#dayend').attr('disabled',true);
            localStorage.setItem('dayend', 1);

        })

        if(localStorage.getItem('breakstartTime')){
            document.getElementById("timer").innerHTML=localStorage.getItem('time').toString();
            $('#daystart').attr('disabled',true);
            $('#breakstart').attr('disabled',true);
            $('#breakend').attr('disabled',false);
            $('#dayend').attr('disabled',true);
        } else if(localStorage.getItem('startTime')){
            start();
        }

        if(localStorage.getItem('dayend')){
            $('#daystart').attr('disabled',true);
            $('#breakstart').attr('disabled',true);
            $('#breakend').attr('disabled',true);
            $('#dayend').attr('disabled',true);
        }

        if(localStorage.getItem('today')){
            var todate = localStorage.getItem('today');

            var d = new Date();
            var month = d.getMonth()+1;
            var day = d.getDate();
            var date = ((''+month).length<2 ? '0' : '') + month + '/' +
                ((''+day).length<2 ? '0' : '') + day+ '/' +d.getFullYear();

            var todayend = localStorage.getItem('dayend');
            if(todate == date && todayend == 1){
                localStorage.removeItem('dayend');
            }else{
                localStorage.removeItem('dayend');
            }
        }else{
            var d = new Date();
            var month = d.getMonth()+1;
            var day = d.getDate();
            var date = ((''+month).length<2 ? '0' : '') + month + '/' +
                ((''+day).length<2 ? '0' : '') + day+ '/' +d.getFullYear();
            localStorage.setItem('today', date);
        }

    </script>
@endsection