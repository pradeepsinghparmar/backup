<!-- Sidebar -->
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion _sidebar-style" id="accordionSidebar">
    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="{{ route('dashboards') }}">
        <div class="sidebar-brand-icon rotate-n-15">
            <!--<i class="fas fa-laugh-wink"></i>-->
            <img src="{{ asset('admin/assets/css/aa.png') }}" width="120">
        </div>
        <!--<div class="sidebar-brand-text mx-3">JWP</div>-->
    </a>

    <!-- Nav Item - Dashboard -->
    <li class="nav-item">
        <a class="nav-link" href="{{ route('dashboards') }}">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span>
        </a>
    </li>
    @if(Auth::user()->role == '1')
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapse1"
            aria-expanded="true" aria-controls="collapseTwo">
            <i class="fas fa-fw fa-chart-area"></i>
            <span>Admin</span>
        </a>
        <div id="collapse1" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="{{ route('role_lists') }}">User Role</a>
                <a class="collapse-item" href="{{ route('role_list') }}">User Permission</a>
            </div>
        </div>
    </li>
    @endif
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo2"
            aria-expanded="true" aria-controls="collapseTwo">
            <i class="fas fa-fw fa-cog"></i>
            <span>Master Data Build</span>
        </a>
        <div id="collapseTwo2" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                @if(App\Models\Permission::admin_permission('employee_list'))
                <a class="collapse-item" href="{{ route('employee_list') }}">Employee Master</a>
                @endif
                @if(App\Models\Permission::admin_permission('vendor'))
                <a class="collapse-item" href="{{ route('vendor_list') }}">Vendor Master</a>
                @endif
                @if(App\Models\Permission::admin_permission('customer_master'))
                <a class="collapse-item" href="{{ route('customer_list') }}">Customer Master</a>
                @endif
                @if(App\Models\Permission::admin_permission('project_master'))
                <a class="collapse-item" href="{{ route('project_list') }}">Project Master</a>
                @endif
                @if(App\Models\Permission::admin_permission('task_master'))
                <a class="collapse-item" href="{{ route('task_list') }}">Task Master</a>
                @endif
                @if(App\Models\Permission::admin_permission('holiday_calender'))
                <a class="collapse-item" href="{{ route('holiday_list') }}">HoliDay Calender</a>
                @endif
            </div>
        </div>
    </li>
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo3"
            aria-expanded="true" aria-controls="collapseTwo">
            <i class="fas fa-fw fa-cog"></i>
            <span>Time Entry Transactions</span>
        </a>
        <div id="collapseTwo3" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="{{ route('attendance.index') }}">Attendance</a>
                <a class="collapse-item" href="">Reports</a>
                @if(App\Models\Permission::admin_permission('holiday_calender'))
                <a class="collapse-item" href="{{ route('holiday_list') }}">HoliDay Calender</a>
                @endif
                <a class="collapse-item" href="">Dashboard</a>
                <a class="collapse-item" href="">Logout</a>
            </div>
        </div>
    </li>
    @if(Auth::user()->role == '1')
        @if(App\Models\Permission::admin_permission('employee_list'))
            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo1"
                    aria-expanded="true" aria-controls="collapseTwo1">
                    <i class="fas fa-fw fa-user"></i>
                    <span>Employee Management</span>
                </a>
                <div id="collapseTwo1" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="{{ route('attendance.index') }}">Attendance List</a>
                        <a class="collapse-item" href="{{ route('holiday_list') }}">Holiday List</a>
                    </div>
                </div>
            </li>
        @endif
    @else
        @if(App\Models\Permission::admin_permission('attendanc_list'))
            <!-- Divider -->
            <!--<hr class="sidebar-divider">-->
            <li class="nav-item">
                <a class="nav-link" href="{{ route('employee_att') }}">
                    <i class="fas fa-fw fa-user"></i>
                    <span>Attendance List</span></a>
            </li>
        @endif   
    @endif
    @if(Auth::user()->role == '1')
        <!-- Nav Item - Pages Collapse Menu -->
        <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
                aria-expanded="true" aria-controls="collapseTwo">
                <i class="fas fa-fw fa-cog"></i>
                <span>Staff Management</span>
            </a>
            <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <a class="collapse-item" href="{{ route('staff_list') }}">Staff List</a>
                </div>
            </div>
        </li>
    @endif
    @if(Auth::user()->role == '1')
        @if(App\Models\Permission::admin_permission('notification'))
            <!-- Nav Item - Utilities Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities"
                    aria-expanded="true" aria-controls="collapseUtilities">
                    <i class="fas fa-fw fa-wrench"></i>
                    <span>Notification</span>
                </a>
                <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities"
                    data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <!--<h6 class="collapse-header">Custom Utilities:</h6>-->
                        <a class="collapse-item" href="{{ route('create_notification') }}">Add Notification</a>
                        <a class="collapse-item" href="{{ route('notification.index') }}">Notification List</a>
                        <a class="collapse-item" href="{{ route('activity_list') }}">Recent Activity List</a>
                    </div>
                </div>
            </li>
        @endif
    @else
        @if(App\Models\Permission::admin_permission('notification'))
            <!-- Nav Item - Utilities Collapse Menu -->
             <li class="nav-item">
                <a class="nav-link" href="{{ route('notification.index') }}">
                    <i class="fas fa-fw fa-bell"></i>
                    <span>Notification List</span></a>
            </li>
        @endif
    @endif
    <!-- Sidebar Toggler (Sidebar) -->
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>
    <!-- Sidebar Message -->
</ul>
<!-- End of Sidebar -->