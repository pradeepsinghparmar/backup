<!DOCTYPE html>
<html leng="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport">
	<title>Email send</title>
</head>
<body class="body" style="padding:0 !important; margin:0 !important; display:block !important; min-width:100% !important; width:100% !important; background:#ffffff; -webkit-text-size-adjust:none;"><span class="mcnPreviewText" style="display:none; font-size:0px; line-height:0px; max-height:0px; max-width:0px; opacity:0; overflow:hidden; visibility:hidden; mso-hide:all;"></span>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
<td align="center" valign="top"><div style="background-color: #ddd; max-width: 650px; padding: 40px 40px 40px 40px; margin-top: 35px;">
<table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#fff"><tr><td align="center" valign="top"><table width="650" border="0" cellspacing="0" cellpadding="0" class="mobile-shell">
<tr>
<td class="img-center" style="font-size:0pt; line-height:0pt; text-align:center;background-image:linear-gradient(to left,#005dad,#0b7cca)!important; padding: 14px 0"><a href="#" target="_blank"><img src="{{ asset('admin/assets/css/jwp.png') }}" width="225" mc:edit="image_1" border="0" alt="" /></a>
</td>
</tr>
</table>
</td>
</tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#fff">
<tr>
<td>
<div mc:repeatable="Select" mc:variant="Section - Intro">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
<td align="center" valign="top" width="650" class="mobile-shell">
<table width="650" border="0" cellspacing="0" cellpadding="0" class="mobile-shell">
<tr>
<td>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
	<td class="plr-15" style="padding: 0 60px 50px 60px;"><table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td class="h1 fw-medium" style="padding-bottom: 20px; padding-top: 40px; color:#4a4a4a; font-family:Arial,sans-serif; font-size:40px; line-height:50px; text-align:center; font-weight:700;">
		<div mc:edit="text_4">Account Opening<p style="font-size: 16px; font-weight:400;">Welcome to <a target="_blank" href="https://jwpitapp.com/public/admin/login/">Clindcast Time Logs</a>.</p>
		</div>
		</td>
	</tr>
	<p style="font-size:21px;">Hi <b >{{$details['name']}}</b>,</p>
	<p>Thank you for joining at our site <b>Clindcast Time Logs</b>.</p>
	<p><b>Your account type is</b> : {{$details['account_type']}}</p>
	<p><b>Email</b> : {{$details['email']}}</p>
	<p><b>Password</b> : {{$details['password']}}</p> 
	<p><b>Web Login</b> : {{$details['web_url']}}</p>
	<p><b>App Login</b> : {{$details['app_url']}}</p>
	</td>
	</tr>
</table>
</td>
</tr>
</table>
</td>
</tr>
</table>
</td>
</tr>
</table>


<table width="100%" border="0" cellspacing="0" cellpadding="0"><tr><td align="center" valign="top"><table width="650" border="0" cellspacing="0" cellpadding="0" class="mobile-shell"  bgcolor="#f4f4f4"><tr><td class="plr-15" style="padding: 20px 30px;"><table width="100%" border="0" cellspacing="0" cellpadding="0"><tr><th class="column-top" valign="top" style="font-size:0pt; line-height:0pt; padding:0; margin:0; font-weight:normal; vertical-align:top;"><table width="100%" border="0" cellspacing="0" cellpadding="0"><tr><td class="text-footer-1 to-right m-center" style="color:#a0a09a; font-family: Arial,sans-serif; font-size:11px; line-height:22px; text-align:center;"><div mc:edit="text_36">Copyright &copy; 2022 - JWP</div></td></tr></table></th></tr></table></td></tr></table></td></tr></table></div></td></tr></table>
</body>
</html>