<?php
    return [
        'guards'=> [
            'employee' => 'employee',
        ]

    ];
